public interface Movimento {
    void mover(double x, double y);
}
